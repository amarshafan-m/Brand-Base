(function (thisObj) {// ----- EXTENDSCRIPT INCLUDES ------ //// ---------------------------------- //// ----- EXTENDSCRIPT PONYFILLS -----// ---------------------------------- //var com_brandbase_premiere_cep = (function (exports) {
  'use strict';

  // ============================
  // Brand Base — Premiere Pro ExtendScript Bridge
  // Supports: Premiere Pro v20+ (2020) through v26+ (2026)
  // ============================

  // ------ Utility: Safely find a project item by its media path ------
  var _findItem = function findItem(item, pathToFind) {
    if (!item) return null;
    try {
      var pType;
      try {
        pType = typeof ProjectItemType !== 'undefined' ? ProjectItemType : null;
      } catch (e) {
        pType = null;
      }
      if (pType) {
        if (item.type === pType.CLIP || item.type === pType.FILE) {
          try {
            if (item.getMediaPath && item.getMediaPath() === pathToFind) return item;
          } catch (e) {}
        }
      } else {
        try {
          if (item.getMediaPath && item.getMediaPath() === pathToFind) return item;
        } catch (e) {}
      }
      if (item.children) {
        var count = 0;
        try {
          count = item.children.numItems || item.children.length || 0;
        } catch (e) {}
        for (var i = 0; i < count; i++) {
          try {
            var found = _findItem(item.children[i], pathToFind);
            if (found) return found;
          } catch (e) {}
        }
      }
    } catch (e) {}
    return null;
  };
  var safeGetInsertionBin = function safeGetInsertionBin() {
    try {
      if (app.project.getInsertionBin) {
        var bin = app.project.getInsertionBin();
        if (bin) return bin;
      }
    } catch (e) {}
    return app.project.rootItem;
  };

  // ------ Utility: Get or Create Bins for Organization ------
  var getOrCreateBin = function getOrCreateBin(parentBin, binName) {
    if (!parentBin) return null;
    try {
      var count = parentBin.children.numItems || 0;
      for (var i = 0; i < count; i++) {
        var child = parentBin.children[i];
        var pType;
        try {
          pType = typeof ProjectItemType !== 'undefined' ? ProjectItemType : null;
        } catch (e) {
          pType = null;
        }
        if (pType && child.type !== pType.BIN && child.type !== 2) continue; // 2 is typically BIN

        if (child.name === binName) return child;
      }
    } catch (e) {}
    try {
      return parentBin.createBin(binName);
    } catch (e) {
      return parentBin;
    }
  };
  var getTargetBinForFile = function getTargetBinForFile(filePath) {
    try {
      var root = app.project.rootItem;
      if (!root) return null;
      var brandBaseBin = getOrCreateBin(root, "Brand Base Assets");
      if (!brandBaseBin) brandBaseBin = root;
      var ext = filePath.split('.').pop().toLowerCase();
      var subBinName = "Other";
      if (ext === 'mp4' || ext === 'mov' || ext === 'avi' || ext === 'webm') subBinName = "Videos";else if (ext === 'mp3' || ext === 'wav' || ext === 'aac' || ext === 'm4a' || ext === 'aif' || ext === 'aiff' || ext === 'flac') subBinName = "Audio";else if (ext === 'png' || ext === 'jpg' || ext === 'jpeg' || ext === 'gif' || ext === 'webp' || ext === 'svg' || ext === 'mogrt') subBinName = "Images";
      return getOrCreateBin(brandBaseBin, subBinName) || brandBaseBin;
    } catch (e) {
      return safeGetInsertionBin();
    }
  };
  var safeImportFiles = function safeImportFiles(filePaths, targetBin) {
    try {
      var r = app.project.importFiles(filePaths, true, targetBin, false);
      if (r !== false) return true;
    } catch (e) {}
    try {
      var r2 = app.project.importFiles(filePaths, true, targetBin);
      if (r2 !== false) return true;
    } catch (e) {}
    try {
      var r3 = app.project.importFiles(filePaths);
      if (r3 !== false) return true;
    } catch (e) {}
    var anyOk = false;
    for (var i = 0; i < filePaths.length; i++) {
      try {
        app.project.importFile(filePaths[i]);
        anyOk = true;
      } catch (e) {
        try {
          app.project.importFile(filePaths[i], true, targetBin, false);
          anyOk = true;
        } catch (e2) {}
      }
    }
    if (!anyOk) {
      try {
        
        app.enableQE();
        if (typeof qe !== 'undefined' && qe.project) {
          for (var j = 0; j < filePaths.length; j++) {
            
            qe.project.importFiles([filePaths[j]]);
            anyOk = true;
          }
        }
      } catch (e) {}
    }
    return anyOk;
  };
  var safeGetPlayerPosition = function safeGetPlayerPosition(seq) {
    try {
      return seq.getPlayerPosition();
    } catch (e) {}
    return {
      ticks: "0",
      seconds: 0
    };
  };
  var bbGetContext = function bbGetContext() {
    try {
      if (!app.project) return {
        projectAvailable: false,
        sequenceAvailable: false
      };
      var seq = null;
      try {
        seq = app.project.activeSequence;
      } catch (e) {}
      return {
        projectAvailable: true,
        projectName: app.project.name || "",
        projectPath: app.project.path || "",
        sequenceAvailable: !!seq,
        sequenceName: seq ? seq.name || "" : undefined,
        sequenceId: seq ? seq.sequenceID || "" : undefined
      };
    } catch (e) {
      return {
        projectAvailable: false,
        sequenceAvailable: false
      };
    }
  };
  var bbGetTimelineContext = function bbGetTimelineContext() {
    try {
      if (!app.project || !app.project.activeSequence) return {
        sequenceAvailable: false
      };
      var seq = app.project.activeSequence;
      var pos = safeGetPlayerPosition(seq);
      var vTracks = 0;
      var aTracks = 0;
      try {
        vTracks = seq.videoTracks.numTracks;
      } catch (e) {}
      try {
        aTracks = seq.audioTracks.numTracks;
      } catch (e) {}
      return {
        sequenceAvailable: true,
        sequenceName: seq.name || "",
        sequenceId: seq.sequenceID || "",
        videoTrackCount: vTracks,
        audioTrackCount: aTracks,
        playheadTicks: pos.ticks || "0",
        playheadSeconds: pos.seconds || 0
      };
    } catch (e) {
      return {
        sequenceAvailable: false
      };
    }
  };
  var bbImportFiles = function bbImportFiles(filePaths) {
    if (!app.project) throw new Error("No active Premiere project.");
    var anyOk = false;
    for (var i = 0; i < filePaths.length; i++) {
      var p = filePaths[i];
      if (!_findItem(app.project.rootItem, p)) {
        var targetBin = getTargetBinForFile(p);
        if (safeImportFiles([p], targetBin)) anyOk = true;
      } else {
        anyOk = true;
      }
    }
    if (!anyOk) throw new Error("Import failed — none of the Premiere import methods succeeded.");
    return true;
  };
  var bbEnsureImported = function bbEnsureImported(nativePath) {
    if (!app.project) throw new Error("No active Premiere project.");
    var targetItem = _findItem(app.project.rootItem, nativePath);
    if (targetItem) return false;
    var targetBin = getTargetBinForFile(nativePath);
    var ok = safeImportFiles([nativePath], targetBin);
    if (!ok) throw new Error("Failed to import file into project.");
    return true;
  };
  var bbPlaceOnTimeline = function bbPlaceOnTimeline(nativePath, placement) {
    if (!app.project) throw new Error("No active Premiere project.");
    var seq = app.project.activeSequence;
    if (!seq) throw new Error("No active sequence.");
    var time = safeGetPlayerPosition(seq);
    var placeTime = time.seconds || 0;
    if (placement.mode !== "playhead" && placement.customTimecode) {
      var parts = placement.customTimecode.split(':');
      if (parts.length === 4) {
        var h = parseInt(parts[0], 10) || 0;
        var m2 = parseInt(parts[1], 10) || 0;
        var s = parseInt(parts[2], 10) || 0;
        var f = parseInt(parts[3], 10) || 0;
        var fps = 30;
        try {
          fps = 254016000000 / parseInt(seq.timebase, 10);
        } catch (e) {}
        placeTime = h * 3600 + m2 * 60 + s + f / fps;
      }
    }
    var placeTimeObj = safeGetPlayerPosition(seq);
    try {
      placeTimeObj.seconds = placeTime;
    } catch (e) {}

    // MOGRT
    if (nativePath.toLowerCase().indexOf('.mogrt') > -1) {
      var vt = placement.videoTrackIndex !== undefined ? placement.videoTrackIndex : 0;
      var at = placement.audioTrackIndex !== undefined ? placement.audioTrackIndex : 0;
      var mogrtOk = false;
      try {
        
        var r1 = seq.importMGT(nativePath, placeTimeObj.ticks, vt, at);
        if (r1) mogrtOk = true;
      } catch (e) {}
      if (!mogrtOk) {
        try {
          
          var r2 = seq.importMGT(nativePath, placeTimeObj, vt, at);
          if (r2) mogrtOk = true;
        } catch (e) {}
      }
      if (!mogrtOk) {
        try {
          
          if (typeof seq.importMGTFromLibrary === 'function') {
            
            var r3 = seq.importMGTFromLibrary(nativePath, placeTimeObj.ticks, vt, at);
            if (r3) mogrtOk = true;
          }
        } catch (e) {}
      }
      if (!mogrtOk) throw new Error("Failed to place MOGRT on timeline.");
      return;
    }
    var targetItem = _findItem(app.project.rootItem, nativePath);
    if (!targetItem) {
      safeImportFiles([nativePath], getTargetBinForFile(nativePath));
      
      try {
        $.sleep(200);
      } catch (e) {}
      targetItem = _findItem(app.project.rootItem, nativePath);
    }
    if (!targetItem) throw new Error("Failed to resolve project item after import.");
    var clipDuration = 0;
    try {
      var outPt = targetItem.getOutPoint();
      var inPt = targetItem.getInPoint();
      if (outPt && inPt) clipDuration = (outPt.seconds || 0) - (inPt.seconds || 0);
      if (clipDuration <= 0) try {
        clipDuration = outPt.seconds || 0;
      } catch (e) {}
    } catch (e) {}
    if (clipDuration <= 0) clipDuration = 10;
    var placeEnd = placeTime + clipDuration;
    var vt2 = placement.videoTrackIndex !== undefined ? placement.videoTrackIndex : 0;
    var at2 = placement.audioTrackIndex !== undefined ? placement.audioTrackIndex : 0;
    if (placement.autoTrack || placement.videoTrackIndex === 'auto') {
      vt2 = 0;
      try {
        for (var i = 0; i < seq.videoTracks.numTracks; i++) {
          var track = seq.videoTracks[i];
          var isOcc = false;
          var nc = 0;
          try {
            nc = track.clips.numItems || 0;
          } catch (e) {}
          for (var c = 0; c < nc; c++) {
            try {
              var cl = track.clips[c];
              if ((cl.start.seconds || 0) < placeEnd && (cl.end.seconds || 0) > placeTime) {
                isOcc = true;
                break;
              }
            } catch (e) {}
          }
          if (!isOcc) {
            vt2 = i;
            break;
          }
          vt2 = i;
        }
      } catch (e) {}
    }
    if (placement.autoTrack || placement.audioTrackIndex === 'auto') {
      at2 = 0;
      try {
        for (var i = 0; i < seq.audioTracks.numTracks; i++) {
          var track = seq.audioTracks[i];
          var isOcc = false;
          var nc = 0;
          try {
            nc = track.clips.numItems || 0;
          } catch (e) {}
          for (var c = 0; c < nc; c++) {
            try {
              var cl = track.clips[c];
              if ((cl.start.seconds || 0) < placeEnd && (cl.end.seconds || 0) > placeTime) {
                isOcc = true;
                break;
              }
            } catch (e) {}
          }
          if (!isOcc) {
            at2 = i;
            break;
          }
          at2 = i;
        }
      } catch (e) {}
    }
    var inserted = false;
    var lastError = "";
    var ext = nativePath.split('.').pop().toLowerCase();
    var isAudioOnly = ext === 'mp3' || ext === 'wav' || ext === 'aac' || ext === 'm4a' || ext === 'aif' || ext === 'aiff' || ext === 'flac';
    if (!isAudioOnly) {
      try {
        var vTrack = seq.videoTracks[vt2];
        if (vTrack) {
          try {
            inserted = !!(placement.editMode === "overwrite" ? vTrack.overwriteClip(targetItem, placeTimeObj) : vTrack.insertClip(targetItem, placeTimeObj));
          } catch (e) {
            lastError = e.message || String(e);
          }
          if (!inserted) {
            try {
              inserted = !!vTrack.insertClip(targetItem, placeTimeObj.ticks);
            } catch (e) {}
          }
          if (!inserted) {
            try {
              inserted = !!vTrack.insertClip(targetItem, placeTime);
            } catch (e) {}
          }
        }
      } catch (e) {
        lastError = lastError || e.message || String(e);
      }
    }
    if (!inserted) {
      try {
        var aTrack = seq.audioTracks[at2];
        if (aTrack) {
          try {
            inserted = !!(placement.editMode === "overwrite" ? aTrack.overwriteClip(targetItem, placeTimeObj) : aTrack.insertClip(targetItem, placeTimeObj));
          } catch (e) {
            lastError = lastError || e.message || String(e);
          }
          if (!inserted) {
            try {
              inserted = !!aTrack.insertClip(targetItem, placeTimeObj.ticks);
            } catch (e) {}
          }
          if (!inserted) {
            try {
              inserted = !!aTrack.insertClip(targetItem, placeTime);
            } catch (e) {}
          }
        }
      } catch (e) {
        lastError = lastError || e.message || String(e);
      }
    }
    if (!inserted) {
      try {
        
        app.enableQE();
        if (typeof qe !== 'undefined' && qe.project) {
          
          var qeSeq = qe.project.getActiveSequence();
          if (qeSeq) {
            
            var qeTrack = isAudioOnly ? qeSeq.getAudioTrackAt(at2) : qeSeq.getVideoTrackAt(vt2);
            if (qeTrack) {
              
              qeTrack.insertClip(nativePath, placeTimeObj.ticks || "0");
              inserted = true;
            }
          }
        }
      } catch (e) {}
    }
    if (!inserted) throw new Error("Failed to place on timeline: " + lastError);
  };
  var bbApplyColorToSelection = function bbApplyColorToSelection(hexColor) {
    if (!app.project) throw new Error("No active Premiere project.");
    var seq = app.project.activeSequence;
    if (!seq) throw new Error("No active sequence.");
    var selection = [];
    try {
      selection = seq.getSelection() || [];
    } catch (e) {}
    if (!selection || selection.length === 0) throw new Error("No clips selected.");
    var hex = hexColor.replace("#", "");
    var r = parseInt(hex.substring(0, 2), 16);
    var g = parseInt(hex.substring(2, 4), 16);
    var b = parseInt(hex.substring(4, 6), 16);
    var colorArr = [r, g, b, 255];
    var colorNorm = [r / 255, g / 255, b / 255, 1.0];
    var applied = false;
    var foundNativeText = false;
    for (var i = 0; i < selection.length; i++) {
      var clip = selection[i];
      if (clip.components) {
        var nc = 0;
        try {
          nc = clip.components.numItems || 0;
        } catch (e) {}
        for (var c = 0; c < nc; c++) {
          try {
            var comp = clip.components[c];
            if (comp.matchName === "AE.ADBE Text") foundNativeText = true;
            if (comp.matchName === "AE.ADBE Motion" || comp.matchName === "AE.ADBE Opacity" || comp.matchName === "AE.ADBE Audio Volume" || comp.matchName === "PR.TimeRemapping") continue;
            var props = comp.properties;
            if (!props) continue;
            var np = 0;
            try {
              np = props.numItems || 0;
            } catch (e) {}
            for (var p = 0; p < np; p++) {
              try {
                var param = props[p];
                var val = param.getValue();
                if (val && typeof val.fontFamily !== 'undefined') {
                  if (typeof val.setFillColor === 'function') {
                    val.setFillColor(r, g, b);
                    applied = true;
                  } else if (typeof val.fillColor !== 'undefined') {
                    val.fillColor = colorArr;
                    applied = true;
                  } else if (typeof val.color !== 'undefined') {
                    val.color = colorArr;
                    applied = true;
                  }
                  if (applied) param.setValue(val);
                }
                var pName = "";
                try {
                  pName = (param.displayName || "").toLowerCase();
                } catch (e) {}
                if (!applied && (pName.indexOf("color") !== -1 || pName.indexOf("fill") !== -1)) {
                  try {
                    param.setValue(colorArr);
                    applied = true;
                  } catch (e) {
                    try {
                      param.setValue(colorNorm);
                      applied = true;
                    } catch (e2) {
                      try {
                        param.setValue(hexColor);
                        applied = true;
                      } catch (e3) {}
                    }
                  }
                }
              } catch (e) {}
            }
          } catch (e) {}
        }
      }
    }
    if (!applied) {
      if (foundNativeText) throw new Error("Cannot apply color: Adobe Premiere Pro does not allow extensions to change the color of Native Graphics (Type Tool). You must use an After Effects MOGRT to apply colors programmatically.");
      throw new Error("Could not apply color directly to the selected graphic layer. Ensure a compatible Essential Graphic is selected.");
    }
  };
  var bbApplyFontToSelection = function bbApplyFontToSelection(fontName) {
    if (!app.project) throw new Error("No active Premiere project.");
    var seq = app.project.activeSequence;
    if (!seq) throw new Error("No active sequence.");
    var selection = [];
    try {
      selection = seq.getSelection() || [];
    } catch (e) {}
    if (!selection || selection.length === 0) throw new Error("No clips selected.");
    var applied = false;
    var foundNativeText = false;
    for (var i = 0; i < selection.length; i++) {
      var clip = selection[i];
      if (clip.components) {
        var nc = 0;
        try {
          nc = clip.components.numItems || 0;
        } catch (e) {}
        for (var c = 0; c < nc; c++) {
          try {
            var comp = clip.components[c];
            if (comp.matchName === "AE.ADBE Text") foundNativeText = true;
            if (comp.matchName === "AE.ADBE Motion" || comp.matchName === "AE.ADBE Opacity" || comp.matchName === "AE.ADBE Audio Volume" || comp.matchName === "PR.TimeRemapping") continue;
            var props = comp.properties;
            if (!props) continue;
            var np = 0;
            try {
              np = props.numItems || 0;
            } catch (e) {}
            for (var p = 0; p < np; p++) {
              try {
                var param = props[p];
                var val = param.getValue();
                if (val && typeof val.fontFamily !== 'undefined') {
                  val.fontFamily = fontName;
                  param.setValue(val);
                  applied = true;
                }
              } catch (e) {}
            }
          } catch (e) {}
        }
      }
    }
    if (!applied) {
      if (foundNativeText) throw new Error("Cannot apply typography: Adobe Premiere Pro does not allow extensions to change the font of Native Graphics (Type Tool). You must use an After Effects MOGRT to apply fonts programmatically.");
      throw new Error("Could not apply font directly to the selected graphic layer. Ensure a compatible Essential Graphic is selected.");
    }
  };
  var bbCreateTextLayer = function bbCreateTextLayer(fontFamily, fontWeight, fontSize, text, hexColor) {
    if (!app.project) throw new Error("No active Premiere project.");
    var seq = app.project.activeSequence;
    if (!seq) throw new Error("No active sequence. Open a sequence first.");
    var hex = hexColor.replace("#", "");
    var r = parseInt(hex.substring(0, 2), 16);
    var g = parseInt(hex.substring(2, 4), 16);
    var b = parseInt(hex.substring(4, 6), 16);
    var created = false;
    try {
      
      app.enableQE();
      if (typeof qe !== 'undefined' && qe.project && qe.project.getActiveSequence) {
        
        var qeSeq = qe.project.getActiveSequence(); 
        if (qeSeq && typeof qeSeq.addGraphicsLayer === 'function') {
          
          qeSeq.addGraphicsLayer();
          created = true;
        }
      }
    } catch (e) {}
    if (created) {
      try {
        var selection = [];
        try {
          selection = seq.getSelection() || [];
        } catch (e) {}
        if (selection && selection.length > 0) {
          var newClip = selection[selection.length - 1];
          if (newClip && newClip.components) {
            var nc = 0;
            try {
              nc = newClip.components.numItems || 0;
            } catch (e) {}
            for (var c = 0; c < nc; c++) {
              try {
                var comp = newClip.components[c];
                if (!comp.properties) continue;
                var np = 0;
                try {
                  np = comp.properties.numItems || 0;
                } catch (e) {}
                for (var p = 0; p < np; p++) {
                  try {
                    var param = comp.properties[p];
                    var val = param.getValue();
                    if (val && typeof val.fontFamily !== 'undefined') {
                      val.fontFamily = fontFamily;
                      if (typeof val.fontSize !== 'undefined') val.fontSize = fontSize;
                      if (typeof val.text !== 'undefined') val.text = text;
                      if (typeof val.setFillColor === 'function') {
                        val.setFillColor(r, g, b);
                      } else if (typeof val.fillColor !== 'undefined') {
                        val.fillColor = [r, g, b, 255];
                      }
                      param.setValue(val);
                    }
                  } catch (e) {}
                }
              } catch (e) {}
            }
          }
        }
      } catch (e) {}
      return {
        success: true,
        method: "graphicsLayer"
      };
    }
    throw new Error("Premiere Pro's ExtendScript API does not support creating Essential Graphics text layers programmatically in this version. " + "Workaround: Use the Type Tool (T) in Premiere Pro to create a text layer on the timeline, select it, then click the typography style to apply the font.");
  };

  function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
  if ((typeof JSON === "undefined" ? "undefined" : _typeof(JSON)) !== "object") {
    JSON = {};
  }
  (function () {

    var rx_one = /^[\],:{}\s]*$/;
    var rx_two = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
    var rx_three = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;
    var rx_four = /(?:^|:|,)(?:\s*\[)+/g;
    var rx_escapable = /[\\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
    var rx_dangerous = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
    function f(n) {
      return n < 10 ? "0" + n : n;
    }
    function this_value() {
      return this.valueOf();
    }
    if (typeof Date.prototype.toJSON !== "function") {
      Date.prototype.toJSON = function () {
        return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + f(this.getUTCMonth() + 1) + "-" + f(this.getUTCDate()) + "T" + f(this.getUTCHours()) + ":" + f(this.getUTCMinutes()) + ":" + f(this.getUTCSeconds()) + "Z" : null;
      };
      Boolean.prototype.toJSON = this_value;
      Number.prototype.toJSON = this_value;
      String.prototype.toJSON = this_value;
    }
    var gap;
    var indent;
    var meta;
    var rep;
    function quote(string) {
      rx_escapable.lastIndex = 0;
      return rx_escapable.test(string) ? "\"" + string.replace(rx_escapable, function (a) {
        var c = meta[a];
        return typeof c === "string" ? c : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
      }) + "\"" : "\"" + string + "\"";
    }
    function str(key, holder) {
      var i;
      var k;
      var v;
      var length;
      var mind = gap;
      var partial;
      var value = holder[key];
      if (value && _typeof(value) === "object" && typeof value.toJSON === "function") {
        value = value.toJSON(key);
      }
      if (typeof rep === "function") {
        value = rep.call(holder, key, value);
      }
      switch (_typeof(value)) {
        case "string":
          return quote(value);
        case "number":
          return isFinite(value) ? String(value) : "null";
        case "boolean":
        case "null":
          return String(value);
        case "object":
          if (!value) {
            return "null";
          }
          gap += indent;
          partial = [];
          if (Object.prototype.toString.apply(value) === "[object Array]") {
            length = value.length;
            for (i = 0; i < length; i += 1) {
              partial[i] = str(i, value) || "null";
            }
            v = partial.length === 0 ? "[]" : gap ? "[\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "]" : "[" + partial.join(",") + "]";
            gap = mind;
            return v;
          }
          if (rep && _typeof(rep) === "object") {
            length = rep.length;
            for (i = 0; i < length; i += 1) {
              if (typeof rep[i] === "string") {
                k = rep[i];
                v = str(k, value);
                if (v) {
                  partial.push(quote(k) + (gap ? ": " : ":") + v);
                }
              }
            }
          } else {
            for (k in value) {
              if (Object.prototype.hasOwnProperty.call(value, k)) {
                v = str(k, value);
                if (v) {
                  partial.push(quote(k) + (gap ? ": " : ":") + v);
                }
              }
            }
          }
          v = partial.length === 0 ? "{}" : gap ? "{\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "}" : "{" + partial.join(",") + "}";
          gap = mind;
          return v;
      }
    }
    if (typeof JSON.stringify !== "function") {
      meta = {
        "\b": "\\b",
        "\t": "\\t",
        "\n": "\\n",
        "\f": "\\f",
        "\r": "\\r",
        "\"": "\\\"",
        "\\": "\\\\"
      };
      JSON.stringify = function (value, replacer, space) {
        var i;
        gap = "";
        indent = "";
        if (typeof space === "number") {
          for (i = 0; i < space; i += 1) {
            indent += " ";
          }
        } else if (typeof space === "string") {
          indent = space;
        }
        rep = replacer;
        if (replacer && typeof replacer !== "function" && (_typeof(replacer) !== "object" || typeof replacer.length !== "number")) {
          throw new Error("JSON.stringify");
        }
        return str("", {
          "": value
        });
      };
    }
    if (typeof JSON.parse !== "function") {
      JSON.parse = function (text, reviver) {
        var j;
        function walk(holder, key) {
          var k;
          var v;
          var value = holder[key];
          if (value && _typeof(value) === "object") {
            for (k in value) {
              if (Object.prototype.hasOwnProperty.call(value, k)) {
                v = walk(value, k);
                if (v !== undefined) {
                  value[k] = v;
                } else {
                  delete value[k];
                }
              }
            }
          }
          return reviver.call(holder, key, value);
        }
        text = String(text);
        rx_dangerous.lastIndex = 0;
        if (rx_dangerous.test(text)) {
          text = text.replace(rx_dangerous, function (a) {
            return "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
          });
        }
        if (rx_one.test(text.replace(rx_two, "@").replace(rx_three, "]").replace(rx_four, ""))) {
          j = eval("(" + text + ")");
          return typeof reviver === "function" ? walk({
            "": j
          }, "") : j;
        }
        throw new SyntaxError("JSON.parse");
      };
    }
  })();

  // ExtendScript Entry Point


  var hostMethod = function hostMethod() {
    return "Hello from ExtendScript";
  };

  var host = typeof $ !== 'undefined' ? $ : window;
  // IMPORTANT: Do NOT use spread operator here ({ ...brandbase })
  // It compiles to _objectSpread() which uses Object.getOwnPropertyDescriptors,
  // Object.defineProperty, etc. — none of which exist in ExtendScript (ES3).
  // This causes silent failure on Windows, leaving the namespace as undefined.

  var bbNamespace = {};
  bbNamespace.hostMethod = hostMethod;
  bbNamespace.bbGetContext = bbGetContext;
  bbNamespace.bbGetTimelineContext = bbGetTimelineContext;
  bbNamespace.bbImportFiles = bbImportFiles;
  bbNamespace.bbEnsureImported = bbEnsureImported;
  bbNamespace.bbPlaceOnTimeline = bbPlaceOnTimeline;
  bbNamespace.bbApplyColorToSelection = bbApplyColorToSelection;
  bbNamespace.bbApplyFontToSelection = bbApplyFontToSelection;
  bbNamespace.bbCreateTextLayer = bbCreateTextLayer;

  host["com_brandbase_premiere_cep"] = bbNamespace;

  exports.bbApplyColorToSelection = bbApplyColorToSelection;
  exports.bbApplyFontToSelection = bbApplyFontToSelection;
  exports.bbCreateTextLayer = bbCreateTextLayer;
  exports.bbEnsureImported = bbEnsureImported;
  exports.bbGetContext = bbGetContext;
  exports.bbGetTimelineContext = bbGetTimelineContext;
  exports.bbImportFiles = bbImportFiles;
  exports.bbPlaceOnTimeline = bbPlaceOnTimeline;
  exports.hostMethod = hostMethod;

  return exports;

})({});
})(this);